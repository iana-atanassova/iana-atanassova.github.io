#!/bin/bash
# Copie les fichiers mis à jour dans le dépôt. Ne fait ni commit ni push.
set -e
REPO="${1:?Indiquer le chemin du dépôt}"
HERE="$(cd "$(dirname "$0")" && pwd)"
cd "$REPO"; [ -d .git ] || { echo "Erreur : pas un dépôt git"; exit 1; }
# Rendre de nouveau modifiables les fichiers copiés en lecture seule par l'archive précédente
find . -path ./.git -prune -o -type f ! -perm -u+w -exec chmod u+w {} +
# Copie sans reprendre les droits des fichiers de l'archive
cp -r --no-preserve=mode,ownership "$HERE/depot/." "$REPO/"
# Cartes d'exemple de la page Outreach remplacées par les vraies cartes
git rm -q --ignore-unmatch _outreach/example_project.md _outreach/2021-anr-inscim.md
# Logos des financeurs (téléchargés depuis les sites officiels)
mkdir -p assets/img/logos
dl() { curl -fsSL -A "Mozilla/5.0" -o "assets/img/logos/$1" "$2" && echo "  logo $1 OK" || echo "  ATTENTION : logo $1 non téléchargé ($2)"; }
dl anr.png "https://anr.fr/typo3conf/ext/anr_skin/Resources/Public/assets/img/anr-logo-2021-complet.png"
dl region-bfc.svg "https://www.bourgognefranchecomte.fr/themes/custom/bourg/logo.svg"
dl stars-eu.png "https://starseu.org/wp-content/uploads/2024/05/2024-StarsEU.png"
dl interreg-france-suisse.svg "https://www.interreg-francesuisse.eu/sites/bfcinterreg/files/2024-12/2022_01_RBFC_INTERREG_LOGO-RGB-ss-fd.svg"
git add -A
git status --short
echo
echo "Optionnel : cd CV-latex && ./compile.sh   (les PDF fournis sont déjà compilés)"
echo "Puis : git commit -m \"MAJ CV et site : nouveaux projets, ARTS, ESSS, RIPEC, corrections\" && git push"
