# Mise à jour CV + site — 20 novembre 2026 (c — remplace la version b)

Cette archive remplace aussi la correction `iana-all.bib` envoyée plus tôt (alignement HAL) : elle est incluse.

## Appliquer

```bash
cd /home/iana/LOCAL-DATA/git/iana-atanassova/iana-atanassova.github.io && git pull
~/Téléchargements/maj-site-2026-11-20-c/appliquer.sh /home/iana/LOCAL-DATA/git/iana-atanassova/iana-atanassova.github.io
# optionnel : recompiler chez vous
cd CV-latex && ./compile.sh && cd ..
git commit -m "MAJ CV et site : nouveaux projets, ARTS, ESSS, RIPEC, corrections" && git push
```

Les PDF du CV (EN/FR) et `_bibliography/iana-all-html.bib` sont fournis déjà compilés/générés (compilation sans erreur).

## Fichiers

| Fichier | Modification |
|---|---|
| `CV-latex/CV_Iana_Atanassova_en.tex` | Version anglaise réellement en anglais (babel `english`, tri `en_US`) ; `babel` chargé une seule fois |
| `CV-latex/CV_Iana_Atanassova_fr.tex` | `babel` chargé une seule fois |
| `CV-latex/content.tex` | Voir ci-dessous (détail dans `content.diff`) |
| `CV-latex/iana-all.bib` | Corrections HAL + article Scientometrics 2026 (DOI) + ARTS 2026 + ESSS 2026 (détail dans `iana-all.diff`) |
| `_bibliography/iana-all-html.bib` | Régénéré |
| `assets/pdf/CV_Iana_Atanassova_{en,fr}.pdf` | Recompilés |
| `_pages/about.md` | IUF : membre honoraire (junior 2021–2026) |
| `_data/socials.yml` | Courriel `@umlp.fr` |
| `_projects/2026-{inscape,safari,f-des,med-ia-lang}.md` | 4 nouvelles cartes (sans montants) |

## Modifications de `content.tex`

- En-tête : « Professeure des universités » (FR), membre honoraire de l'IUF, courriel `@umlp.fr`, liens en https.
- Position actuelle : IUF membre honoraire depuis 09/2026 (junior 09/2021–08/2026).
- Projets PI : INSCAPE (2026–2028, 109K€), SAFARI (2026–2027, 56K€), F-DES (2026–2027, 14K€), MED-IA-LANG (2026–2029, 53K€ pour le CRIT, titre complet et partenaires CLA et Goelang).
- Encadrement postdoctoral : Dr Francis Lareau (11/2026–10/2028, INSCAPE).
- Prix et distinctions : RIPEC C3 (2026–2029).
- Coquilles : Gutehrlé (×3), BIBLIOVISOP / Visual, Université, annotation, International / Informetrics (×2), juries, AITEC, Bibliometric-enhanced IR.
- Accords au féminin : Participante (×6), Évaluatrice (×4), Membre élue (ED LECLA).
- DOI de l'éditorial Frontiers 2019 corrigé (10.3389/frma.2019.00002 au lieu du DOI 2022).
- UFR SLHS : « Faculty of Language, Human and Social Sciences ».
- Mémoires de Master et enseignement 2024– : Université Marie et Louis Pasteur.
- « IUF dans le cartable » : verbes au passé (EN).
- Formation : « Sofia, Bulgaria » en anglais.
