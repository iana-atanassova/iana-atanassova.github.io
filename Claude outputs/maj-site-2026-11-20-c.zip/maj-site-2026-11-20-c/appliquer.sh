#!/bin/bash
# Copie les fichiers mis à jour dans le dépôt. Ne fait ni commit ni push.
set -e
REPO="${1:?Indiquer le chemin du dépôt}"
HERE="$(cd "$(dirname "$0")" && pwd)"
cd "$REPO"; [ -d .git ] || { echo "Erreur : pas un dépôt git"; exit 1; }
# Rendre de nouveau modifiables les fichiers copiés en lecture seule par l'archive précédente
find . -path ./.git -prune -o -type f ! -perm -u+w -exec chmod u+w {} +
# Copie sans reprendre les droits des fichiers de l'archive
cp -r --no-preserve=mode,ownership "$HERE/depot/." "$REPO/"
git add -A
git status --short
echo
echo "Optionnel : cd CV-latex && ./compile.sh   (les PDF fournis sont déjà compilés)"
echo "Puis : git commit -m \"MAJ CV et site : nouveaux projets, ARTS, ESSS, RIPEC, corrections\" && git push"
