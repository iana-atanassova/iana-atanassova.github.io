---
start_date: 2021-01-01   # used to order cards (most recent first)
layout: page
title: ANR InSciM
description: Modelling Uncertainty in Science, 2021-2025
img: assets/img/inscim1.png
category: PI of Funded Projects
related_publications: false
---

The ANR InSciM Project is funded by <a href="https://anr.fr/Projet-ANR-21-CE38-0003" target="_blank">French ANR JCJC, grant number ANR-21-CE38-0003-01</a> (2021-2025). 

Objectives: Create a linguistic model of scientific uncertainty and tools for its annotation in articles across disciplines.

Visit the <strong><a href="https://project-inscim.github.io/" target="_blank">ANR InSciM Project Official Home Page</a></strong>.