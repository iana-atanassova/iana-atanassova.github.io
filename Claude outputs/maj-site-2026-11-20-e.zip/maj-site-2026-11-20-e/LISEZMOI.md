# Mise à jour CV + site — 20 novembre 2026 (e — remplace les versions b, c et d)

Archive cumulative : elle contient tout le contenu des versions b et c, plus les ajouts ci-dessous.

## Appliquer

```bash
cd /home/iana/LOCAL-DATA/git/iana-atanassova/iana-atanassova.github.io && git pull
bash ~/Téléchargements/maj-site-2026-11-20-e/appliquer.sh /home/iana/LOCAL-DATA/git/iana-atanassova/iana-atanassova.github.io
git commit -m "MAJ CV et site : jurys, projets, outreach, menu" && git push
```

Le script rend d'abord modifiables les fichiers restés en lecture seule, puis copie `depot/` sans reprendre les droits. Il supprime les deux cartes d'exemple de la page Outreach. Ni commit ni push.

## Contenu (cumulé)

**CV LaTeX** (`CV-latex/`, PDF recompilés dans `assets/pdf/`, détail dans `content.diff`)
- Version anglaise en anglais ; corrections de coquilles et accords ; IUF membre honoraire ; @umlp.fr ; RIPEC C3.
- Projets INSCAPE, SAFARI, F-DES, MED-IA-LANG ; postdoc F. Lareau.
- Jurys de thèse 2026 : rapporteure (J. Aubert-Béduchaud, Nantes Université ; Y. Ozturk, Université Grenoble Alpes), présidente (F. Charpentier, Université Lumière Lyon 2).
- Enseignement : cours ESSS 2026 (Leuven).
- Nouvelle section « Encadrement » (avant l'encadrement postdoctoral) ; thèse de Thu Huong Do (2026–, co-direction J. Gaber et M. Olinga, UTBM) ; comités de suivi : M. Rabiei (2025, 2026), O. E. López Manchola, C. A. Rosas Hinostroza (2026).
- `iana-all.bib` : alignement HAL, article Scientometrics 2026, ARTS 2026, ESSS 2026 ; titre de la carte scientifique 2014 corrigé (« The Cognitive Context of Citations »).

**Site**
- Menu : About, Publications, Projects, Outreach, CV.
- Projects : 14 cartes (4 nouvelles PI 2026, 6 participations), triées par date de début (champ `start_date`, du plus récent au plus ancien).
- Outreach : 9 cartes (IUF dans le cartable 2026, ESSS 2026, jeux de données Zenodo, ISTEX 2025, TimeWorld 2025, UnScientify, TEDonnées, articles et entretiens, carte scientifique 2014) ; cartes d'exemple supprimées ; tri par `start_date`.
- `about.md` (IUF honoraire), `socials.yml` (@umlp.fr), `HELP_modifs.md` (champ `start_date`).

Dates de début approximées au 1er janvier quand le mois n'est pas connu (InSciM, e-Cole, BIBLIOVISOP, Epistemic concepts, TheoScit, SEO-ELP, WebSO+, SARS, UnScientify) : elles ne servent qu'au tri.
