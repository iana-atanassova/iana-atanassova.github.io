# Mise à jour CV + site — 20 novembre 2026 (g — remplace les versions b à f)

Archive cumulative : elle contient tout le contenu des versions b et c, plus les ajouts ci-dessous.

## Appliquer

```bash
cd /home/iana/LOCAL-DATA/git/iana-atanassova/iana-atanassova.github.io && git pull
bash ~/Téléchargements/maj-site-2026-11-20-g/appliquer.sh /home/iana/LOCAL-DATA/git/iana-atanassova/iana-atanassova.github.io
git commit -m "MAJ CV et site : jurys, projets, outreach, menu" && git push
```

Le script rend d'abord modifiables les fichiers restés en lecture seule, puis copie `depot/` sans reprendre les droits. Il supprime les deux cartes d'exemple de la page Outreach. Ni commit ni push.

## Contenu (cumulé)

**CV LaTeX** (`CV-latex/`, PDF recompilés dans `assets/pdf/`, détail dans `content.diff`)
- Version anglaise en anglais ; corrections de coquilles et accords ; IUF membre honoraire ; @umlp.fr ; RIPEC C3.
- Projets INSCAPE, SAFARI, F-DES, MED-IA-LANG ; postdoc F. Lareau.
- Jurys de thèse 2026 : rapporteure (J. Aubert-Béduchaud, Nantes Université ; Y. Ozturk, Université Grenoble Alpes), présidente (F. Charpentier, Université Lumière Lyon 2).
- Enseignement : cours ESSS 2026 (Leuven).
- Nouvelle section « Encadrement » (avant l'encadrement postdoctoral) ; thèse de Thu Huong Do (2026–, co-direction J. Gaber et M. Olinga, UTBM) ; comités de suivi : M. Rabiei (2025, 2026), O. E. López Manchola, C. A. Rosas Hinostroza (2026).
- `iana-all.bib` : alignement HAL, article Scientometrics 2026, ARTS 2026, ESSS 2026 ; titre de la carte scientifique 2014 corrigé (« The Cognitive Context of Citations »).

**Site**
- Menu : About, Publications, Projects, Outreach, CV.
- Projects : 14 cartes (4 nouvelles PI 2026, 6 participations), triées par date de début (champ `start_date`, du plus récent au plus ancien).
- Outreach : 9 cartes (IUF dans le cartable 2026, ESSS 2026, jeux de données Zenodo, ISTEX 2025, TimeWorld 2025, UnScientify, TEDonnées, articles et entretiens, carte scientifique 2014) ; cartes d'exemple supprimées ; tri par `start_date`.
- `about.md` (IUF honoraire), `socials.yml` (@umlp.fr), `HELP_modifs.md` (champ `start_date`).

Dates de début approximées au 1er janvier quand le mois n'est pas connu (InSciM, e-Cole, BIBLIOVISOP, Epistemic concepts, TheoScit, SEO-ELP, WebSO+, SARS, UnScientify) : elles ne servent qu'au tri.

## Ajouts de la version f

- **Selected publications** : « Patterns of uncertainty in astrobiology publications » (Scientometrics 2026) ajouté (`selected = {true}`).
- **Images** : `assets/img/inscape.png` (carte INSCAPE), `assets/img/f-des.png` (carte F-DES, couleurs de Global Data Excellence), `assets/img/unscientify.png` (carte Outreach UnScientify). Images générées par programme, libres de droits.
- **Logos des financeurs** sur les cartes : liste des financeurs dans `_data/funders.yml`, champ `funders: [anr]` dans chaque carte. Le script télécharge les logos ANR, Région BFC, STARS EU et Interreg France-Suisse dans `assets/img/logos/`. Un financeur sans logo s'affiche sous forme de pastille texte.
- **Cartes « participante »** (`card_only: true`) : non cliquables, fond et liseré de couleur différents, informations principales et liens affichés sur la carte (ex. TheoScit avec lien vers anr.fr).
- **InSciM** renommé « InSciM - Modelling Uncertainty in Science ». **F-DES** : lien vers la page de la formation.
- **Outreach** : UnScientify épinglé en première position (`pinned: true`).
- Fichiers techniques : `_includes/projects_horizontal.liquid`, `_includes/funders.liquid`, `_sass/_custom.scss`, `assets/css/main.scss` (import de `custom`).

## Ajouts de la version g

- **Carte scientifique 2014** : image du poster ajoutée (`assets/img/science-map-2014.jpg`) ; titre corrigé en « The Linguistic Context of Citations » (titre du poster) dans la carte, le CV et `iana-all.bib`.
- **UnScientify** : nouvelle image avec des expressions multi-mots surlignées et la distinction incertitude des auteurs / incertitude des travaux cités.
- **Outreach** : « Open Datasets » et « Articles and Interviews » placés à la fin (`position: last`) ; carte « IUF dans le cartable » avec son image (téléchargée par le script) ; espacement vertical corrigé (`mb-4` dans `_includes/projects.liquid`).
- **Pages de projets et d'outreach** : l'image de la carte s'affiche aussi sur la page (`_layouts/page.liquid`), avec les logos des financeurs (section « Funding »).
- **Logos des financeurs** : zone pleine largeur en bas de la carte, sous l'image ; chaque logo occupe au plus 70 % de la largeur de la carte et 80 px de hauteur, sans déformation (`_sass/_custom.scss`).
- **CV** : encadrement postdoctoral de Dr Panggih Kusuma Ningrum (projet SAFARI, 09/2026–08/2027).
